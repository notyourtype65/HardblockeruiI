plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.hardblocker"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.hardblocker"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0"
        // Set this to your published Floot app URL once the friend-approval backend is live
        buildConfigField("String", "BACKEND_URL", "\"https://YOUR-APP.floot.app\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1") }
