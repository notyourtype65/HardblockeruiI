package com.hardblocker

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        if (LockManager.isLocked(context)) "Hard mode is active. This can't be disabled until the lock is released."
        else "Disabling protection."
}
