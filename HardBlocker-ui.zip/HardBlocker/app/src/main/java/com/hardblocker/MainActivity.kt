package com.hardblocker

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.LinearLayout.LayoutParams as LP

private val TEXT = Color.parseColor("#111827")
private val BG = Color.parseColor("#FFFFFF")
private val CARD = Color.parseColor("#FFF1F6")
private val CHIP = Color.parseColor("#FBDDE9")
private val ACCENT = Color.parseColor("#E8478B")
private val OK = Color.parseColor("#22A559")
private val WARN = Color.parseColor("#E5484D")
private val MUTED = Color.parseColor("#6B7280")
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {
    private val admin by lazy { ComponentName(this, AdminReceiver::class.java) }
    private val dpm by lazy { getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager }
    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var choice = "TIMER"
    private var days = 7
    private val tick = object : Runnable { override fun run() { render(); handler.postDelayed(this, 30_000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(32), dp(16), dp(32)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true; addView(root) })
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r == 1 && c == RESULT_OK) startService(Intent(this, BlockerVpnService::class.java))
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun rounded(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = sp; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        background = rounded(CARD, 20)
        layoutParams = LP(MATCH, WRAP).apply { bottomMargin = dp(12) }
    }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(if (primary) Color.WHITE else ACCENT)
        background = rounded(if (primary) ACCENT else CHIP, 14)
        layoutParams = LP(MATCH, dp(48)).apply { topMargin = dp(12) }
        setOnClickListener { onClick() }
    }

    private fun chip(label: String, selected: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(if (selected) Color.WHITE else MUTED)
        background = rounded(if (selected) ACCENT else CHIP, 12)
        layoutParams = LP(0, dp(42), 1f).apply { marginEnd = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun row(done: Boolean, title: String, sub: String, onEnable: () -> Unit): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        r.addView(tv(if (done) "✓" else "○", 20f, if (done) OK else MUTED, true).apply { layoutParams = LP(dp(32), WRAP) })
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LP(0, WRAP, 1f) }
        mid.addView(tv(title, 15f, TEXT, true)); mid.addView(tv(sub, 12f, MUTED))
        r.addView(mid)
        if (!done) r.addView(tv("Enable", 14f, ACCENT, true).apply { setPadding(dp(12), dp(8), dp(4), dp(8)); setOnClickListener { onEnable() } })
        return r
    }

    private fun vpnOn(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
    }
    private fun a11yOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(packageName) == true
    private fun fmt(ms: Long): String { val h = ms / 3_600_000; val d = h / 24; return if (d >= 1) "${d}d ${h % 24}h" else "${h}h ${(ms / 60_000) % 60}m" }

    private fun render() {
        root.removeAllViews()
        val mode = LockManager.mode(this); val locked = LockManager.isLocked(this)
        val vpn = vpnOn(); val a11y = a11yOn(); val adm = dpm.isAdminActive(admin)
        val done = listOf(vpn, a11y, adm).count { it }

        root.addView(tv("Hard Blocker", 28f, TEXT, true))
        root.addView(tv("Stay clean. Stay focused.", 14f, MUTED).apply { setPadding(0, 0, 0, dp(16)) })

        // Status ring
        val rc = card().apply { gravity = Gravity.CENTER_HORIZONTAL }
        val ring = RingView(this)
        val status: String
        if (locked && mode == "TIMER") {
            val rem = LockManager.timerRemaining(this); val total = LockManager.timerTotal(this).coerceAtLeast(1)
            ring.progress = 1f - rem.toFloat() / total; ring.ringColor = WARN
            ring.big = if (rem >= 86_400_000) "${rem / 86_400_000}d" else "${rem / 3_600_000}h"; ring.small = "until unlock"
            status = "Hard mode is ON"
        } else if (locked) {
            ring.progress = 1f; ring.ringColor = WARN; ring.big = "LOCKED"; ring.small = "friend approval"
            status = "Hard mode is ON"
        } else {
            ring.progress = done / 3f; ring.ringColor = if (done == 3) OK else ACCENT
            ring.big = "$done/3"; ring.small = "protection set up"
            status = if (done == 3) "You're fully protected" else "Finish setup to be fully protected"
        }
        rc.addView(ring, LP(dp(200), dp(200)))
        rc.addView(tv(status, 14f, MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) })
        root.addView(rc)

        // Protection checklist
        val pc = card()
        pc.addView(tv("Protection", 17f, TEXT, true))
        pc.addView(row(vpn, "Block adult sites", "Filters every app and browser") {
            VpnService.prepare(this)?.let { startActivityForResult(it, 1) } ?: startService(Intent(this, BlockerVpnService::class.java)).also { render() }
        })
        pc.addView(row(a11y, "Block Reels & Shorts", "Turn on Hard Blocker in Accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        pc.addView(row(adm, "Stop uninstalling", "Device Admin protection") {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Prevents uninstalling while hard mode is on."))
        })
        root.addView(pc)

        // Hard mode
        val hc = card()
        if (mode == "NONE") {
            hc.addView(tv("Hard mode", 17f, TEXT, true))
            hc.addView(tv("Once on, you can't turn protection off or uninstall until it ends.", 12f, MUTED).apply { setPadding(0, dp(2), 0, dp(12)) })
            val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            modes.addView(chip("Timer lock", choice == "TIMER") { choice = "TIMER"; render() })
            modes.addView(chip("Friend approval", choice == "FRIEND") { choice = "FRIEND"; render() })
            hc.addView(modes)
            if (choice == "TIMER") {
                hc.addView(tv("Lock for", 12f, MUTED).apply { setPadding(0, dp(12), 0, dp(6)) })
                val ds = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                listOf(1, 3, 7, 14, 30).forEach { d -> ds.addView(chip("${d}d", days == d) { days = d; render() }) }
                hc.addView(ds)
            } else if (BuildConfig.BACKEND_URL.contains("YOUR-APP")) {
                hc.addView(tv("Friend server isn't set up yet, so this mode is switched off for now.", 12f, WARN).apply { setPadding(0, dp(12), 0, 0) })
            } else {
                hc.addView(tv("Your friend gets a code and must approve before you can unlock.", 12f, MUTED).apply { setPadding(0, dp(12), 0, 0) })
            }
            hc.addView(button("Start hard mode", true) { confirmStart() })
        } else if (locked && mode == "TIMER") {
            hc.addView(tv("Timer lock", 17f, TEXT, true))
            hc.addView(tv("Unlocks in ${fmt(LockManager.timerRemaining(this))}", 14f, MUTED).apply { setPadding(0, dp(4), 0, 0) })
        } else if (locked) {
            val code = LockManager.friendCode(this)
            hc.addView(tv("Friend approval", 17f, TEXT, true))
            hc.addView(tv("Friend code: $code", 20f, WARN, true).apply { setPadding(0, dp(8), 0, dp(2)) })
            hc.addView(tv("Share this code with your friend. They approve your unlock requests.", 12f, MUTED))
            hc.addView(button("Share code with friend", false) {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, "Be my accountability partner. Open ${BuildConfig.BACKEND_URL} and enter code $code"), "Share"))
            })
            hc.addView(button("Request / check unlock", true) { requestUnlock() })
        } else {
            hc.addView(tv("Lock finished", 17f, TEXT, true))
            hc.addView(tv("You can release the lock and uninstall if you want.", 12f, MUTED).apply { setPadding(0, dp(2), 0, 0) })
            hc.addView(button("Release lock", true) { release() })
        }
        root.addView(hc)
    }

    private fun confirmStart() {
        if (!dpm.isAdminActive(admin)) { toast("Turn on \"Stop uninstalling\" first"); return }
        if (choice == "FRIEND" && BuildConfig.BACKEND_URL.contains("YOUR-APP")) { toast("Friend server isn't set up yet"); return }
        val msg = if (choice == "TIMER") "Locked for $days day(s). You won't be able to uninstall or turn off protection until time is up."
        else "You won't be able to uninstall or turn off protection until your friend approves."
        AlertDialog.Builder(this).setTitle("Start hard mode?").setMessage(msg).setNegativeButton("Cancel", null)
            .setPositiveButton("Lock it in") { _, _ ->
                if (choice == "TIMER") LockManager.startTimer(this, days) else toast("Friend code: " + LockManager.startFriend(this))
                render()
            }.show()
    }

    private fun requestUnlock() {
        Thread {
            val ok = try { LockManager.requestAndCheck(this) } catch (e: Exception) { false }
            runOnUiThread {
                if (ok) release() else { toast("Request sent. Waiting for your friend."); render() }
            }
        }.start()
    }

    private fun release() {
        if (LockManager.releaseIfAllowed(this)) { dpm.removeActiveAdmin(admin); toast("Unlocked") } else toast("Still locked")
        render()
    }
}
