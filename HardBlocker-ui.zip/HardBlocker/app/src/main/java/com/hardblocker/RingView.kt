package com.hardblocker

import android.content.Context
import android.graphics.*
import android.view.View

class RingView(c: Context) : View(c) {
    var progress = 0f
    var big = ""
    var small = ""
    var ringColor = Color.parseColor("#E8478B")
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.parseColor("#F9D3E3") }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val tBig = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Color.parseColor("#111827"); typeface = Typeface.DEFAULT_BOLD }
    private val tSmall = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Color.parseColor("#6B7280") }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val stroke = w * 0.07f
        track.strokeWidth = stroke; arc.strokeWidth = stroke; arc.color = ringColor
        val r = RectF(stroke, stroke, w - stroke, height - stroke)
        cv.drawArc(r, 0f, 360f, false, track)
        cv.drawArc(r, -90f, 360f * progress.coerceIn(0f, 1f), false, arc)
        tBig.textSize = w * 0.2f; tSmall.textSize = w * 0.07f
        val y = height / 2f + tBig.textSize * 0.15f
        cv.drawText(big, w / 2, y, tBig)
        cv.drawText(small, w / 2, y + tSmall.textSize * 1.8f, tSmall)
    }
}
