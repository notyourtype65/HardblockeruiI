package com.hardblocker

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/** Local DNS-only VPN: blocked domains get NXDOMAIN, everything else goes to Cloudflare Family DNS (1.1.1.3, adult-blocking). */
class BlockerVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    @Volatile private var running = false
    private val blocked by lazy { assets.open("blocklist.txt").bufferedReader().readLines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }.toSet() }
    private val keywords = listOf("porn", "xxx", "xvideos", "xnxx", "xhamster", "hentai")

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) {
            tun = Builder().setSession("Hard Blocker").addAddress("10.0.0.1", 32).addDnsServer("10.0.0.2").addRoute("10.0.0.2", 32).establish() ?: return START_NOT_STICKY
            running = true
            Thread { loop() }.start()
        }
        return START_STICKY
    }

    private fun loop() {
        val input = FileInputStream(tun!!.fileDescriptor); val out = FileOutputStream(tun!!.fileDescriptor)
        val buf = ByteArray(32767)
        while (running) {
            val n = input.read(buf); if (n < 28) { Thread.sleep(5); continue }
            if ((buf[0].toInt() shr 4) != 4 || buf[9].toInt() != 17) continue
            val pkt = buf.copyOf(n); val ihl = (pkt[0].toInt() and 15) * 4
            val dns = pkt.copyOfRange(ihl + 8, n)
            Thread {
                val resp = answer(dns) ?: return@Thread
                synchronized(out) { out.write(build(pkt, ihl, resp)) }
            }.start()
        }
    }

    private fun answer(dns: ByteArray): ByteArray? {
        val sb = StringBuilder(); var i = 12
        while (i < dns.size && dns[i].toInt() != 0) { val l = dns[i].toInt(); sb.append(String(dns, i + 1, l)).append('.'); i += l + 1 }
        val host = sb.toString().trimEnd('.').lowercase()
        if (isBlocked(host)) {
            val r = dns.copyOf(i + 5); r[2] = 0x81.toByte(); r[3] = 0x83.toByte()
            r[6] = 0; r[7] = 0; r[8] = 0; r[9] = 0; r[10] = 0; r[11] = 0
            return r
        }
        return try {
            DatagramSocket().use { s ->
                protect(s); s.soTimeout = 3000
                s.send(DatagramPacket(dns, dns.size, InetAddress.getByName("1.1.1.3"), 53))
                val rb = ByteArray(4096); val rp = DatagramPacket(rb, rb.size); s.receive(rp); rb.copyOf(rp.length)
            }
        } catch (_: Exception) { null }
    }

    private fun isBlocked(h: String): Boolean =
        keywords.any { h.contains(it) } || generateSequence(h) { it.substringAfter('.', "").ifEmpty { null } }.any { it in blocked }

    private fun build(req: ByteArray, ihl: Int, resp: ByteArray): ByteArray {
        val o = ByteArray(ihl + 8 + resp.size); System.arraycopy(req, 0, o, 0, ihl + 8)
        for (k in 0 until 4) { o[12 + k] = req[16 + k]; o[16 + k] = req[12 + k] }
        for (k in 0 until 2) { o[ihl + k] = req[ihl + 2 + k]; o[ihl + 2 + k] = req[ihl + k] }
        val ul = 8 + resp.size; o[ihl + 4] = (ul shr 8).toByte(); o[ihl + 5] = ul.toByte(); o[ihl + 6] = 0; o[ihl + 7] = 0
        val tl = o.size; o[2] = (tl shr 8).toByte(); o[3] = tl.toByte(); o[10] = 0; o[11] = 0
        System.arraycopy(resp, 0, o, ihl + 8, resp.size)
        var sum = 0; for (k in 0 until ihl step 2) sum += ((o[k].toInt() and 255) shl 8) or (o[k + 1].toInt() and 255)
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val c = sum.inv() and 0xFFFF; o[10] = (c shr 8).toByte(); o[11] = c.toByte()
        return o
    }

    override fun onRevoke() { running = false; tun?.close() }
    override fun onDestroy() { running = false; tun?.close() }
}
