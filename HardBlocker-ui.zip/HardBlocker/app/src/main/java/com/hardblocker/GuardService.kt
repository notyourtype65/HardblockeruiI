package com.hardblocker

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 1) Kicks you out of Reels / Shorts / TikTok.
 * 2) While hard mode is locked, bounces you out of Settings screens that could disable or uninstall this app.
 * NOTE: view IDs change between app versions; update REEL_IDS when apps update.
 */
class GuardService : AccessibilityService() {
    private val reelIds = listOf(
        "com.instagram.android:id/clips_viewer_view_pager",
        "com.instagram.android:id/clips_tab",
        "com.google.android.youtube:id/reel_player_page_container",
        "com.google.android.youtube:id/reel_recycler",
        "com.facebook.katana:id/reels_viewer_pager"
    )
    private val blockedApps = setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
    private val settingsPkgs = setOf("com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller")

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg in blockedApps) { performGlobalAction(GLOBAL_ACTION_HOME); return }
        val root = rootInActiveWindow ?: return
        if (pkg in settingsPkgs && LockManager.isLocked(this) && touchesThisApp(root)) {
            performGlobalAction(GLOBAL_ACTION_HOME); return
        }
        if (reelIds.any { id -> root.findAccessibilityNodeInfosByViewId(id).any { it.isVisibleToUser } }) {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun touchesThisApp(root: AccessibilityNodeInfo): Boolean {
        val keys = listOf("Hard Blocker", "Device admin", "Device administrator", "Accessibility", "Uninstall", "VPN")
        return keys.any { root.findAccessibilityNodeInfosByText(it).isNotEmpty() } &&
            root.findAccessibilityNodeInfosByText("Hard Blocker").isNotEmpty()
    }

    override fun onInterrupt() {}
}
