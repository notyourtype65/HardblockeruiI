package com.hardblocker

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Hard-mode state. TIMER = locked until time passes. FRIEND = locked until friend approves. */
object LockManager {
    private fun p(c: Context) = c.getSharedPreferences("lock", Context.MODE_PRIVATE)
    private fun boot(c: Context) = Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, 0)

    fun mode(c: Context) = p(c).getString("mode", "NONE")!!
    fun timerTotal(c: Context) = p(c).getLong("durationMs", 0)

    fun startTimer(c: Context, days: Int) {
        p(c).edit().putString("mode", "TIMER").putLong("durationMs", days * 86_400_000L)
            .putLong("startWall", System.currentTimeMillis()).putLong("startElapsed", SystemClock.elapsedRealtime())
            .putInt("boot", boot(c)).apply()
    }

    fun startFriend(c: Context): String {
        // deviceCode is a secret kept only in the app (never shown), so the user can't approve their own unlock.
        // friendCode is shown and given to the friend, who can only approve with it.
        val device = UUID.randomUUID().toString().replace("-", "")
        val friend = UUID.randomUUID().toString().take(8).uppercase()
        p(c).edit().putString("mode", "FRIEND").putString("code", device).putString("friend", friend).putBoolean("approved", false).apply()
        Thread { post("/api/unlock/register", """{"code":"$device","friendCode":"$friend"}""") }.start()
        return friend
    }

    fun friendCode(c: Context) = p(c).getString("friend", "") ?: ""

    /** Remaining ms for timer mode. Uses the monotonic clock within a boot, so changing the date can't shorten it. */
    fun timerRemaining(c: Context): Long {
        val s = p(c); val total = s.getLong("durationMs", 0)
        val usedWall = System.currentTimeMillis() - s.getLong("startWall", 0)
        val usedMono = if (s.getInt("boot", -1) == boot(c)) SystemClock.elapsedRealtime() - s.getLong("startElapsed", 0) else usedWall
        // Wall clock moved backwards? Ignore it. Take the larger of the two only if monotonic is unavailable.
        val used = if (s.getInt("boot", -1) == boot(c)) usedMono else maxOf(usedWall, 0)
        return (total - used).coerceAtLeast(0)
    }

    fun isLocked(c: Context): Boolean = when (mode(c)) {
        "TIMER" -> timerRemaining(c) > 0
        "FRIEND" -> !p(c).getBoolean("approved", false)
        else -> false
    }

    /** Friend mode: ask the backend for approval, then poll. Returns true if approved. */
    fun requestAndCheck(c: Context): Boolean {
        val code = p(c).getString("code", "") ?: ""
        post("/api/unlock/request", """{"code":"$code"}""")
        val conn = URL(BuildConfig.BACKEND_URL + "/_api/unlock/status?code=$code").openConnection() as HttpURLConnection
        val ok = try { JSONObject(conn.inputStream.bufferedReader().readText()).optString("status") == "approved" } catch (e: Exception) { false }
        if (ok) p(c).edit().putBoolean("approved", true).apply()
        return ok
    }

    fun releaseIfAllowed(c: Context): Boolean {
        if (isLocked(c)) return false
        p(c).edit().putString("mode", "NONE").apply()
        return true
    }

    private fun post(path: String, json: String) {
        try {
            val u = URL(BuildConfig.BACKEND_URL + path.replace("/api/", "/_api/")).openConnection() as HttpURLConnection
            u.requestMethod = "POST"; u.doOutput = true; u.setRequestProperty("Content-Type", "application/json")
            u.outputStream.use { it.write(json.toByteArray()) }
            u.responseCode
        } catch (_: Exception) {}
    }
}
